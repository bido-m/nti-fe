import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { faHeart, faCartShopping, faMagnifyingGlass, faUser, faRightFromBracket } from '@fortawesome/free-solid-svg-icons';
import { AuthService } from '../../Service/auth';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterLink, FontAwesomeModule],
  styleUrl: './navbar.css',
  templateUrl: './navbar.html',
})
export class Navbar {
  faHeart = faHeart;
  faCartShopping = faCartShopping;
  faMagnifyingGlass = faMagnifyingGlass;
  faUser = faUser;
  faRightFromBracket = faRightFromBracket;

  constructor(public authService: AuthService, private router: Router) {}

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
