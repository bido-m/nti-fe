import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

export interface Category {
  id: number;
  name: string;
  icon?: string;
  created_at?: string;
}

export interface Product {
  id: number;
  title: string;
  description?: string | null;
  price: number;
  image_url?: string | null;
  category_id?: number | null;
  stock: number;
  created_at?: string;
  updated_at?: string;
  category?: Category;
  specifications?: { [key: string]: string };
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'user';
  created_at?: string;
}

export interface CartItem {
  id: number;
  cart_id: number;
  product_id: number;
  quantity: number;
  product?: Product;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly baseUrl = 'https://fdrvjaenuuvinwpqkpxq.supabase.co/rest/v1';
  private readonly apiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZkcnZqYWVudXV2aW53cHFrcHhxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk2ODEyNzEsImV4cCI6MjEwNTI1NzI3MX0.6yEzYr6DSlR2j-we7occmRtsKT2qNGzvN2D-57C2DyM';

  private readonly defaultCategories: Category[] = [
    { id: 1, name: 'Watches', icon: 'watch' },
    { id: 2, name: 'Jewelry', icon: 'gem' },
    { id: 3, name: 'Bags & Leather', icon: 'bag' },
    { id: 4, name: 'Perfumes', icon: 'spray' },
    { id: 5, name: 'Smartphones & Tech', icon: 'mobile' }
  ];

  private readonly defaultProducts: Product[] = [
    {
      id: 1,
      title: 'OPPO Find X9 Titanium Edition',
      description: 'Ultra-flagship smartphone featuring aerospace-grade titanium frame, Hasselblad pro-grade quad camera, Snapdragon 8 Elite processor, and 120Hz LTPO AMOLED display.',
      price: 7500,
      image_url: 'https://www.oppo.com/content/dam/oppo/common/mkt/v2-2/find-x9-series-en/feature/find-x9/640-640-titanium-v2.png',
      category_id: 5,
      stock: 14,
      specifications: {
        'Processor': 'Snapdragon 8 Elite (3nm)',
        'RAM & Storage': '16GB LPDDR5X / 512GB UFS 4.0',
        'Camera': '50MP Sony Dual Periscope + 50MP Wide',
        'Battery & Charging': '5400mAh with 100W SuperVOOC',
        'Materials': 'Titanium Frame & Ultra-Ceramic Glass'
      }
    },
    {
      id: 2,
      title: 'Rolex Submariner Date 41mm',
      description: 'The archetype of the diver watch in robust Oystersteel with unidirectional rotatable Cerachrom bezel, solid black dial, and high-precision automatic 3235 caliber movement.',
      price: 14500,
      image_url: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=800',
      category_id: 1,
      stock: 5,
      specifications: {
        'Case Diameter': '41 mm Oystersteel',
        'Bezel': 'Cerachrom ceramic with 60-minute graduations',
        'Movement': 'Calibre 3235, Manufacture Rolex',
        'Water Resistance': '300 metres / 1,000 feet',
        'Power Reserve': 'Approximately 70 hours'
      }
    },
    {
      id: 3,
      title: 'Cartier Love Bracelet 18K Yellow Gold',
      description: 'A timeless icon of romantic commitment created in 1969. Beautifully contoured oval design studded with functional screw motifs in 750/1000 yellow gold.',
      price: 7200,
      image_url: 'https://images.unsplash.com/photo-1611591475883-7925e01f56fa?w=800',
      category_id: 2,
      stock: 8,
      specifications: {
        'Material': '18K Yellow Gold (750/1000)',
        'Width': '6.1 mm',
        'Closure': 'Ergonomic screw system with gold screwdriver',
        'Origin': 'Handcrafted in Switzerland',
        'Certificate': 'Cartier Certificate of Authenticity'
      }
    },
    {
      id: 4,
      title: 'Hermès Birkin 30 Gold Togo Leather',
      description: 'The epitome of Parisian luxury and craftsmanship. Carefully handcrafted by a single artisan using velvety grain Togo calfskin paired with radiant gold-plated hardware.',
      price: 24500,
      image_url: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800',
      category_id: 3,
      stock: 3,
      specifications: {
        'Dimensions': '30 cm x 22 cm x 16 cm',
        'Leather': 'Togo Fine Grain Veau Calfskin',
        'Hardware': '24K Gold-Plated Palladium',
        'Interior': 'Chevre goatskin with zip pocket',
        'Includes': 'Clochette, lock, two keys, dustbag, and box'
      }
    },
    {
      id: 5,
      title: 'Tom Ford Oud Wood Eau de Parfum 100ml',
      description: 'Smoky, artisanal composition built around exotic rosewood and cardamom before revealing rich notes of rare oud wood, sandalwood, vetiver, and creamy amber.',
      price: 395,
      image_url: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?w=800',
      category_id: 4,
      stock: 22,
      specifications: {
        'Volume': '100 ml / 3.4 fl. oz.',
        'Fragrance Family': 'Warm & Woody',
        'Key Notes': 'Rare Oud Wood, Sandalwood, Chinese Pepper',
        'Concentration': 'Eau de Parfum Spray',
        'Longevity': 'Long-lasting (8-12 hours)'
      }
    },
    {
      id: 6,
      title: 'Omega Speedmaster Professional Moonwatch',
      description: 'The world-famous chronograph certified for space exploration. Equipped with the Co-Axial Master Chronometer Calibre 3861 and sapphire crystal caseback.',
      price: 8100,
      image_url: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=800',
      category_id: 1,
      stock: 7,
      specifications: {
        'Case Size': '42 mm Stainless Steel',
        'Crystal': 'Domed scratch-resistant sapphire crystal',
        'Movement': 'Manual-winding Omega Calibre 3861',
        'Certification': 'METAS Master Chronometer certified',
        'Magnetic Resistance': 'Up to 15,000 gauss'
      }
    },
    {
      id: 7,
      title: 'Van Cleef & Arpels Vintage Alhambra Onyx',
      description: 'Faithful to the very first Alhambra jewel created in 1968, this iconic four-leaf clover pendant features polished deep black onyx delicately bordered by golden beads.',
      price: 3100,
      image_url: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?w=800',
      category_id: 2,
      stock: 11,
      specifications: {
        'Stone': 'Natural Black Onyx (1 stone)',
        'Metal': '18K Yellow Gold',
        'Chain Length': '42 cm adjustable to 38 cm',
        'Hallmark Clasp': 'Small model 18K yellow gold',
        'Authenticity': 'Official Van Cleef & Arpels certificate'
      }
    },
    {
      id: 8,
      title: 'Louis Vuitton Neverfull MM Monogram',
      description: 'Timeless luxury tote bag crafted from supple Monogram coated canvas with natural cowhide leather trim, slim handles, side laces, and a removable patterned pouch.',
      price: 2030,
      image_url: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800',
      category_id: 3,
      stock: 15,
      specifications: {
        'Dimensions': '31 x 28 x 14 cm',
        'Material': 'Monogram coated canvas with cowhide leather',
        'Lining': 'Striped textile interior lining',
        'Hardware': 'Gold-color metallic pieces',
        'Accessories': 'Removable zippered pouch with matching interior'
      }
    },
    {
      id: 9,
      title: 'Maison Francis Kurkdjian Baccarat Rouge 540',
      description: 'An intoxicating oriental floral masterpiece combining airy jasmine blossoms and radiance of saffron with freshly cut cedarwood and ambergris accords.',
      price: 465,
      image_url: 'https://images.unsplash.com/photo-1547887537-6158d64c35b3?w=800',
      category_id: 4,
      stock: 18,
      specifications: {
        'Volume': '70 ml / 2.4 fl. oz.',
        'Type': 'Extrait de Parfum',
        'Top Notes': 'Grandiflorum Jasmine, Saffron',
        'Heart Notes': 'Bitter Almond, Cedarwood',
        'Base Notes': 'Musky Woody Accord, Ambergris'
      }
    },
    {
      id: 10,
      title: 'Apple iPhone 16 Pro Max 1TB Desert Titanium',
      description: 'Crafted from aerospace-grade Grade 5 titanium with an expansive 6.9-inch Super Retina XDR OLED, A18 Pro silicon, dedicated Camera Control key, and 4K 120fps Dolby Vision.',
      price: 1599,
      image_url: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800',
      category_id: 5,
      stock: 25,
      specifications: {
        'Chipset': 'A18 Pro chip with 6-core GPU and Neural Engine',
        'Display': '6.9-inch Super Retina XDR with ProMotion up to 120Hz',
        'Storage': '1TB NVMe internal storage',
        'Camera': '48MP Fusion + 48MP Ultra Wide + 12MP 5x Telephoto',
        'Chassis': 'Microblasted Grade 5 Titanium'
      }
    }
  ];

  private get headers(): HttpHeaders {
    return new HttpHeaders({
      'apikey': this.apiKey,
      'Authorization': `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation'
    });
  }

  constructor(private http: HttpClient) {}

  getCategories(): Observable<Category[]> {
    const params = new HttpParams().set('select', '*');
    return this.http.get<Category[]>(`${this.baseUrl}/categories`, {
      headers: this.headers,
      params
    }).pipe(
      map((cats) => {
        if (cats && cats.length > 0) {
          return cats;
        }
        return this.defaultCategories;
      }),
      catchError(() => of(this.defaultCategories))
    );
  }

  getProducts(categoryId?: number, searchQuery?: string): Observable<Product[]> {
    let params = new HttpParams().set('select', '*');
    if (categoryId) {
      params = params.set('category_id', `eq.${categoryId}`);
    }
    if (searchQuery && searchQuery.trim()) {
      params = params.set('title', `ilike.%${searchQuery.trim()}%`);
    }

    return this.http.get<Product[]>(`${this.baseUrl}/products`, {
      headers: this.headers,
      params
    }).pipe(
      map((remoteProds) => {
        const categoriesMap = new Map<number, Category>();
        for (const c of this.defaultCategories) {
          categoriesMap.set(c.id, c);
        }

        let combined: Product[] = [];
        if (remoteProds && remoteProds.length > 0) {
          const remoteIds = new Set(remoteProds.map(p => p.id));
          const enrichedRemote = remoteProds.map(p => {
            const defaultMatch = this.defaultProducts.find(dp => dp.id === p.id);
            return {
              ...p,
              description: p.description || defaultMatch?.description || 'Exclusive luxury product with guaranteed authenticity and premium finish.',
              specifications: p.specifications || defaultMatch?.specifications || {
                'Warranty': '2 Years Official International Warranty',
                'Authenticity': '100% Certified Original',
                'Delivery': 'Complimentary Insured Express Shipping'
              },
              category: categoriesMap.get(p.category_id || 0)
            };
          });

          const supplemental = this.defaultProducts.filter(p => !remoteIds.has(p.id));
          combined = [...enrichedRemote, ...supplemental];
        } else {
          combined = [...this.defaultProducts];
        }

        combined = combined.map(p => ({
          ...p,
          category: p.category || (p.category_id ? categoriesMap.get(p.category_id) : undefined)
        }));

        if (categoryId) {
          combined = combined.filter(p => p.category_id === categoryId);
        }
        if (searchQuery && searchQuery.trim()) {
          const q = searchQuery.trim().toLowerCase();
          combined = combined.filter(p =>
            p.title.toLowerCase().includes(q) ||
            (p.description && p.description.toLowerCase().includes(q))
          );
        }

        return combined;
      }),
      catchError(() => {
        let list = [...this.defaultProducts];
        const categoriesMap = new Map<number, Category>();
        for (const c of this.defaultCategories) {
          categoriesMap.set(c.id, c);
        }
        list = list.map(p => ({
          ...p,
          category: p.category_id ? categoriesMap.get(p.category_id) : undefined
        }));

        if (categoryId) {
          list = list.filter(p => p.category_id === categoryId);
        }
        if (searchQuery && searchQuery.trim()) {
          const q = searchQuery.trim().toLowerCase();
          list = list.filter(p =>
            p.title.toLowerCase().includes(q) ||
            (p.description && p.description.toLowerCase().includes(q))
          );
        }
        return of(list);
      })
    );
  }

  getProductById(id: number | string): Observable<Product | null> {
    const numId = Number(id);
    const params = new HttpParams().set('id', `eq.${id}`).set('select', '*');

    return this.http.get<Product[]>(`${this.baseUrl}/products`, {
      headers: this.headers,
      params
    }).pipe(
      map((prods) => {
        const categoriesMap = new Map<number, Category>();
        for (const c of this.defaultCategories) {
          categoriesMap.set(c.id, c);
        }

        let found: Product | undefined;
        if (prods && prods.length > 0) {
          found = prods[0];
          const defaultMatch = this.defaultProducts.find(dp => dp.id === found?.id);
          found = {
            ...found,
            description: found.description || defaultMatch?.description || 'Exclusive luxury product designed with precision and uncompromising standards of excellence.',
            specifications: found.specifications || defaultMatch?.specifications || {
              'Warranty': '2 Years Official International Warranty',
              'Authenticity': '100% Certified Original',
              'Shipping': 'Insured Express Courier Shipping',
              'Return Policy': '30-Day Hassle-Free Return Guarantee'
            },
            category: categoriesMap.get(found.category_id || 0)
          };
        } else {
          found = this.defaultProducts.find(dp => dp.id === numId);
          if (found) {
            found = {
              ...found,
              category: found.category_id ? categoriesMap.get(found.category_id) : undefined
            };
          }
        }

        return found || null;
      }),
      catchError(() => {
        const found = this.defaultProducts.find(dp => dp.id === numId) || null;
        if (found) {
          const categoriesMap = new Map<number, Category>();
          for (const c of this.defaultCategories) {
            categoriesMap.set(c.id, c);
          }
          return of({
            ...found,
            category: found.category_id ? categoriesMap.get(found.category_id) : undefined
          });
        }
        return of(null);
      })
    );
  }

  createProduct(product: Partial<Product>): Observable<Product[]> {
    return this.http.post<Product[]>(`${this.baseUrl}/products`, product, {
      headers: this.headers
    });
  }

  getUserCart(userId: string): Observable<any[]> {
    const params = new HttpParams().set('user_id', `eq.${userId}`).set('select', '*');
    return this.http.get<any[]>(`${this.baseUrl}/carts`, {
      headers: this.headers,
      params
    });
  }

  addToCart(item: { cart_id: number; product_id: number; quantity: number }): Observable<CartItem[]> {
    return this.http.post<CartItem[]>(`${this.baseUrl}/cart_items`, item, {
      headers: this.headers
    });
  }
}
