import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap, switchMap, of, catchError } from 'rxjs';
import { User } from './api';

export interface AuthSession {
  access_token: string;
  token_type: string;
  expires_in: number;
  user: {
    id: string;
    email: string;
    user_metadata?: { name?: string };
  };
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly authUrl = 'https://fdrvjaenuuvinwpqkpxq.supabase.co/auth/v1';
  private readonly restUrl = 'https://fdrvjaenuuvinwpqkpxq.supabase.co/rest/v1';
  private readonly apiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZkcnZqYWVudXV2aW53cHFrcHhxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODk2ODEyNzEsImV4cCI6MjEwNTI1NzI3MX0.6yEzYr6DSlR2j-we7occmRtsKT2qNGzvN2D-57C2DyM';

  private currentUserSubject = new BehaviorSubject<User | null>(this.getStoredUser());
  public currentUser$: Observable<User | null> = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient) {}

  private get headers(): HttpHeaders {
    return new HttpHeaders({
      'apikey': this.apiKey,
      'Content-Type': 'application/json'
    });
  }

  public get currentUser(): User | null {
    return this.currentUserSubject.value;
  }

  signUp(name: string, email: string, password: string): Observable<any> {
    const body = { email, password, data: { name } };
    return this.http.post<any>(`${this.authUrl}/signup`, body, { headers: this.headers }).pipe(
      switchMap((res) => {
        const userId = res?.user?.id || res?.id;
        if (userId) {
          const userRecord: User = { id: userId, name, email, role: 'user' };
          const restHeaders = this.headers.set('Authorization', `Bearer ${this.apiKey}`);
          return this.http.post(`${this.restUrl}/users`, userRecord, { headers: restHeaders }).pipe(
            catchError(() => of(null)),
            tap(() => this.setUserSession(userRecord, res.access_token))
          );
        }
        return of(res);
      })
    );
  }

  signIn(email: string, password: string): Observable<AuthSession> {
    const body = { email, password };
    return this.http.post<AuthSession>(`${this.authUrl}/token?grant_type=password`, body, { headers: this.headers }).pipe(
      tap((session) => {
        const user: User = {
          id: session.user.id,
          email: session.user.email,
          name: session.user.user_metadata?.name || session.user.email.split('@')[0],
          role: 'user'
        };
        this.setUserSession(user, session.access_token);
      })
    );
  }

  logout(): void {
    localStorage.removeItem('lux_token');
    localStorage.removeItem('lux_user');
    this.currentUserSubject.next(null);
  }

  private setUserSession(user: User, token?: string): void {
    if (token) localStorage.setItem('lux_token', token);
    localStorage.setItem('lux_user', JSON.stringify(user));
    this.currentUserSubject.next(user);
  }

  private getStoredUser(): User | null {
    try {
      const stored = localStorage.getItem('lux_user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  }
}
